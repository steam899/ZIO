#!/system/xbin/sh

cd /sdcard/bot
python runble.py &
python rumble.py &
python rumble.py

sleep 5
sh s.sh
